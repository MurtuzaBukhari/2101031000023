<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    $username = "root";
    $servername = "Localhost";
    $password = "";
    $DB = "mydb23";

    $con = mysqli_connect($servername,$username,$password,$DB);
    if (!$con){
        die("Connection Failed".mysqli_connect_error());
    }
    $sql = "INSERT INTO info(Name,Password) VALUES('Murtuza','Mac#2004'),('Karan','Kac#2004'),('Harsh','Hac#2004'),('Jaival','Jac#2003')";
if(mysqli_query($con,$sql))
{
    echo "Insert Successfully";
}
else{
    echo "Error";
}
</body>
</html>