<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database</title>
</head>
<body>
<?php
    $username = "root";
    $servername = "Localhost";
    $password = "";
    $DB = "mydb23";
    $con = mysqli_connect($servername,$username,$password,$DB);
        if (!$con){
            die("Connection Failed".mysqli_connect_error());
        }
    $sql = "create database myDB_2";
        if(mysqli_query($con,$sql))
        {
            echo "DataBase Created";
        }
        else{
            echo "Error";
        }
?>

</body>
</html>