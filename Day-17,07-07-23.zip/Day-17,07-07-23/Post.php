<?php
$name=$_POST['user'];
$pass=$_POST['pass'];

$username = "root";
    $servername = "localhost";
    $password = "";
    $DB = "myDB";

    $con = mysqli_connect($servername,$username,$password,$DB);
    if (!$con){
        die("Connection Failed".mysqli_connect_error());
    }
// else{
//     echo "Connected Succesfully";
// }
// $sql = "create database my_1";
//         if(mysqli_query($con,$sql))
//         {
//             echo "DataBase Created";
//         }
//         else{
//             echo "Error";
//         }
        // $sql = "create table form_details(Name varchar(50) , Password varchar(25))" ;
        // if(mysqli_query($con,$sql))
        // {
        //     echo "Table Created";
        // }
        // else{
        //     echo "Error";
        // }
        $sql = "INSERT INTO form_details(Name,Password) VALUES('$name','$pass')";
        if(mysqli_query($con,$sql))
        {
            echo "Insert Successfully";
        }
        else{
            echo "Error";
        }
?>