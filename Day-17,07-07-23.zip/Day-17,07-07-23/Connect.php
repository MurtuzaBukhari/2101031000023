    <?php
    $username = "root";
    $servername = "Localhost";
    $password = "";
    $DB = "mydb23";

    $con = mysqli_connect($servername,$username,$password,$DB);
    if (!$con){
        die("Connection Failed".mysqli_connect_error());
    }
else{
    echo "Connected Succesfully";
}
?>