<?php
$fname=$_POST['Fname'];
$lname=$_POST['Lname'];
$email=$_POST['Email'];
$contact=$_POST['Contact'];
$area=$_POST['Area'];

$username = "root";
    $servername = "localhost";
    $password = "";
    $DB = "FeedBack_Form";

    $con = mysqli_connect($servername,$username,$password,$DB);
    if (!$con){
        die("Connection Failed".mysqli_connect_error());
    }
// else{
//     echo "Connected Succesfully";
// }
// $sql = "create database FeedBack_Form";
//         if(mysqli_query($con,$sql))
//         {
//             echo "DataBase Created";
//         }
//         else{
//             echo "Error";
//         }
// $sql = "create table FeedBack_form_details(id int(25) AUTO_INCREMENT PRIMARY KEY,First_Name varchar(25),Last_Name varchar(25),Email varchar(50),Contact bigint(10),FeedBack varchar(100))" ;
//         if(mysqli_query($con,$sql))
//         {
//             echo "Table Created";
//         }
//         else{
//             echo "Error";
//         }
        $sql = "INSERT INTO FeedBack_form_details(First_Name,Last_Name,Email,Contact,FeedBack) VALUES('$fname','$lname','$email','$contact','$area')";
        if(mysqli_query($con,$sql))
        {
            echo "Insert Successfully";
        }
        else{
            echo "Error";
        }
        // echo $fname;
        // echo "<br>";
        // echo $lname;
        // echo "<br>";
        // echo $email;
        // echo "<br>";
        // echo $contact;
        // echo "<br>";
        // echo $area;
        // echo "<br>";
?>