<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> FeedBack Form</title>
    <link href="css/bootstrap/bootstrap.css" type="text/css" rel="stylesheet" />
    <script src="Form.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
        type="text/css" />
    <style>
        
        #CNAForm {
            /* color: seagreen; */
            padding-bottom: 1%;
            box-shadow: 0px 0px 10px seagreen;
            margin-top: 4%;
            margin-bottom: 4%;
        }

        #CNAForm b {
            color: seagreen;
        }

        h3,
        i {
            color: seagreen;
        }

        small {
            color: red;
        }
    </style>
</head>

<body>
    <form action="Form.php" method="post" id="form1" name="form1">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-offset-3 col-sm-6 col-md-offset-4 col-md-4 col-lg-offset-4 col-lg-4"
                    id="CNAForm">
                    <h3 class="text-center"><i class="fa fa-comment" style="font-size:25px;"> Feedback Form</i></h3>
                    <hr>
                    <div class="form-group">
                        <b>First Name</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"
                                    style="font-size:20px; color:seagreen;"></i></span>
                            <input type="text" id="fname" name="Fname" placeholder="Enter First Name Here...." maxlength="25"
                                class="form-control">
                        </div>
                        <small class="text-danger" id="fnameval"></small>
                    </div>
                    <div class="form-group">
                        <b>Last Name</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"
                                    style="font-size:20px; color:seagreen;"></i></span>
                            <input type="text" id="lname" name="Lname" placeholder="Enter Last Name Here...." maxlength="25"
                                class="form-control">
                        </div>
                        <small class="text-danger" id="lnameval"></small>
                    </div>
                    <div class="form-group">
                        <b>Email</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"
                                    style="font-size:20px; color:seagreen;"></i></span>
                            <input type="text" id="email" name="Email" placeholder="Enter Email Here...." maxlength="25"
                                class="form-control">
                        </div>
                        <small class="text-danger" id="emailval"></small>
                    </div>
                    <div class="form-group">
                        <i class="fa fa-phone" style="font-size:15px; color:seagreen;"></i>
                        <b>contact</b>
                        <div class="input-group">
                            <span class="input-group-addon"><b>+91</b></span>
                            <input type="text" id="contact" name="Contact" placeholder="Enter Contact Here...." maxlength="10"
                                class="form-control">
                        </div>
                        <small class="text-danger" id="contactval"></small>
                    </div>
                    <div class="form-group">
                        <b><i class="fa fa-comments" style="font-size:20px; color:seagreen;"></i>FeedBack</b>
                        <div class="input-group">
                            <textarea id="area" rows="5" cols="30" name="Area" placeholder="Enter Contact Msg Here.... "></textarea>
                        </div>
                        <small class="text-danger" id="areaval"></small>
                    </div>
                    <div class=form-group">
                        <!-- <button id="B" class="btn btn-success"> Submit </button>
                        <button id="btnReset" class="btn btn-success"> Reset </button> -->
                        <input type="submit" placeholder="Submit" class="btn btn-success" id="B">
                        <input type="reset" placeholder="Reset" class="btn btn-success" id="btnReset">
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>

</html>