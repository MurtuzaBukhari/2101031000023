<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Array</title>
</head>
<body>
    <?php
    $a = array(1,2,3,4,5,6,7,8);
    print_r($a);
    ?>
</body>
</html>