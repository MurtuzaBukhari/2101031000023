<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Merge </title>
</head>
<body>
    <?php
    $arr = array(1,2,3,4,5);
    $arr_1 = array(6,7,8,9,0);
    print_r($arr);
    echo "<br>";
    print_r($arr_1);
    echo "<br>";
    $merge = array_merge($arr,$arr_1);
    print_r($merge);
    ?>
</body>
</html>