<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>String Functions</title>
</head>
<body>
    <?php
    $a = "Welcome To My World";
    echo $a;
    echo "<br>";
    echo strlen($a);
    echo "<br>";
    echo strtoupper($a);
    echo "<br>";
    echo strtolower($a);
    echo "<br>";
    echo ord($a);
    echo "<br>";
    echo str_replace("W","H",$a);
    echo "<br>";
    echo strrev( $a);
    ?>
</body>
</html>