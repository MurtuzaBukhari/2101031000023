<?php
$user=$_GET['user'];
$pass=$_GET['pass'];
echo $user;
echo "<br>";
echo $pass;
?>