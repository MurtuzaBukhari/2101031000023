<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maths Funtions</title>
</head>
<body>
    <?php
    $num = 106;
    echo abs($num);
    echo "<br>";
    echo pow(2,3);
    echo "<br>";
    echo min(11,23,65,74,95);
    echo "<br>";
    $num_1 = 616.996;
    echo ceil($num_1);
    ?>

</body>
</html>