<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="Get.php" id="form1" name="form1" method="get">
        UserName : <input type="text"  id="username" name="user"><br><br>
        Password : <input type="text"  id="password" name="pass"><br><br>
        <input type="submit" name="submit" id="submit"> 
    </form>
</body>
</html>  