<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Array</title>
</head>
<body>
    <?php
    $a = array(1,11,111,1111,11111);
    $sum = 0;
    foreach($a as $value){
        $sum = $sum+$value;
    }
    echo "<br>";
    echo "Sum of given array : ".$sum;
    ?>
</body>
</html>