<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Count</title>
</head>
<body>
    <?php
    $arr = array(5,10,15,20,25);
    echo count($arr);
    ?>
</body>
</html>