<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reverse </title>
</head>
<body>
    <?php
    $arr = array(5,4,3,2,1);
   
    print_r($arr);
    echo "<br>";
    

    $reverse_merge = array_reverse($arr,);
    print_r($reverse_merge)
    ?>

</body>
</html>