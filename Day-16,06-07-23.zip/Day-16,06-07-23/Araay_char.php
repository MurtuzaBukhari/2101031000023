<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Char Array</title>
</head>
<body>
    <?php
    $arr=array("xyz","abc","def","ghi");
    print_r($arr);
    sort($arr);
    echo "After Sorting<br>";
    print_r($arr);
    ?>
</body>
</html>