<?php
$user=$_POST['user'];
$pass=$_POST['pass'];
echo $user;
echo "<br>";
echo $pass;
?>