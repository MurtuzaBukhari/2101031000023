function demoExternalAlert(){
    alert("External Alert")
}
function demoExternalConfirm() {
    if (confirm("Are you sure")) {
        alert("Yess");
    }
    else {
        alert("Nooo");
    }
}
function demoExternalPrompt() {
    var Fname=prompt("Enter First Name Here");
    var Lname=prompt("Enter Last Name Here")
    alert(Fname+" "+Lname);
}