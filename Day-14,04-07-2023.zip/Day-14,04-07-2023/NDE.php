<?php
$name = "Murtuza Bukhari";
$dept = "IT";
$enroll = "2101031000023";

echo $name;
echo "<br>";
echo $dept;
echo "<br>";
echo $enroll;

?>