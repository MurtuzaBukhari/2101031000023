<?php
$num_1 = 41;
$num_2 = 23;
echo "Value of Number_1 : ",$num_1;
echo "<br>";
echo "Value of Number_2 : ",$num_2;
echo "<br>";
$add = $num_1+$num_2;
$sub = $num_1-$num_2;
$mul = $num_1*$num_2;
$div = $num_1/$num_2;

echo "Addition of Number_1 and Number_2 : ",$add;
echo "<br>";
echo "Substraction of Number_1 and Number_2 : ",$sub;
echo "<br>";
echo "Multiplication of Number_1 and Number_2 : ",$mul;
echo "<br>";
echo "Division of Number_1 and Number_2 : ",$div;
?>