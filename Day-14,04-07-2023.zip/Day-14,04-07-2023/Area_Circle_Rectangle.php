<?php
$radius = 7;
$pi = 3.14;
$area_c = $radius*$radius*$pi;
echo "Arae of Circle : ",$area_c;

$len = 5;
$hei = 17;
$area_r = $len*$hei;
echo "<br>";
echo "Area of Rectangle : ",$area_r;
?>