<?php
    $username = "root";
    $servername = "Localhost";
    $password = "";
    $DB = "DataBase_2";

    $con = mysqli_connect($servername,$username,$password,$DB);
    if (!$con){
        die("Connection Failed".mysqli_connect_error());
    }
// else{
//     echo "Connected Succesfully";
// }

$sql = "select * from details_1";
$result = mysqli_query($con,$sql);
$res1 = mysqli_num_rows($result);
if ($res1 > 0)
{
    while($row = mysqli_fetch_assoc($result)){
        echo "ID = ".$row["i'd"]."<br>"."Firstname = ".$row["FirstName"]."<br>"."Lastname = ".$row["LastName"]."<br>"."Contact = ".$row["Contact"]."<br>"."Email = ".$row["E-mail"]."<br>";
    }
}
else{
    echo "No Record";
}
?>