﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DATA_TYPE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int myNum = 5;              
            double myDoubleNum = 5.99D;  
            char myLetter = 'D';         
            bool myBool = true;          
            string myText = "Hello";     
            Console.WriteLine(myNum);
            Console.WriteLine(myDoubleNum);
            Console.WriteLine(myLetter);
            Console.WriteLine(myBool);
            Console.WriteLine(myText);

        }
    }
}
