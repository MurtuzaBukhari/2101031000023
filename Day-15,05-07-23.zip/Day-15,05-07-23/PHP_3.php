<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Third_Demo</title>
</head>
<body>
    <?php
    $c = "123abc";
    echo "Value of C :".$c."<br>";
    echo "Type of C is :".gettype($c);
    settype($c,"int");    
    echo "<br>";
    echo "After type Convertion Type of C is :".gettype($c);
    ?>
</body>
</html>