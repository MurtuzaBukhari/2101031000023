<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IF ELSE STATEMENT</title>
</head>
<body>
<?php
    $A = 20;
    $B = 57;

    echo ($A>$B)?($A."Is Greater"):($B."Is Greater");
    // if ($A > $B){
    //   echo $A." is Greater";
    // }
    // else{
    //    echo $B." is Greater";
    // }
    ?>
</body>
</html>