<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Star</title>
</head>
<body>
<?php
   $i;
   $j;
   $k;
   for($i=1; $i<=5; $i++) { for($j=4; $j>=$i; $j--)
       {
           echo" ";
       }
       for($k=1; $k<=(2*$i-1); $k++)
       {
           echo("*");
       }
       echo("\n")."<br>";
   }
?>
</body>
</html>