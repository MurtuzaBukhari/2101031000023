<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Php First_Demo</title>
</head>
<body>
    <?php
    print "Hello World"."<br>";
    print "How are you"."<br>";
    
    echo "<br>";
    echo "<br>";
    echo "<br>";
    

    ?>
</body>
</html>