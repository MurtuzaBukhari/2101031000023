<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> WHILE LOOP</title>
</head>
<body>
    <?php
    $i=1;
    while($i<=10){
        echo "2 *".$i."=".$i*2;
        echo "<br>";
        $i++;
    }
    ?>
</body>
</html>