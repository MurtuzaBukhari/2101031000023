<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Second_Demo</title>
</head>
<body>
    <?php
$A = 10;
    $B = 21;
    echo "<br>";
    echo "<br>";
    echo "<br>";
    echo "Value of A is :".$A."<br>";
    echo "Value of B is :".$B."<br>";
    echo "Addition of  A and B :".$A+$B."<br>";
    echo "Substract of  A and B :".$A-$B."<br>";
    echo "Multiply of  A and B :".$A*$B."<br>";
    echo "Division of  A and B :".$A/$B."<br>";
    ?>
</body>
</html>