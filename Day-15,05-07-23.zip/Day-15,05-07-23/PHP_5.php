<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> NESTED IF ELSE STATEMENT</title>
</head>
<body>
<?php
   $num_1 = 20;
   $num_2 = 146;
   $num_3 = 94;
  
   if ($num_1 > $num_2 ){
        if ($num_1 > $num_3 ){
            echo $num_1."IS GREATER THAN";
        }
        else{
            echo $num_3."Is GREATER THAN";
        }
   }
   
   else {
        if ($num_2 > $num_3 ){
            echo $num_2." IS GREATER THAN ".$num_1." AND ".$num_3;
        }
        else{
            echo $num_3."Is GREATER THAN".$num_2;
        }
   }

   ?> 
</body>
</html>